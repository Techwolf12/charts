# Changelog

| Chart version | App version | Change description |
| :------------ | :---------- | :----------------- |
| 1.0.0 | 7.2.5 | Initial version of Valkey chart (based on Redis chart) |
| 1.0.1 | 7.2.6 | Updated to Valkey 7.2.6 |
| 1.0.2 | 7.2.6 | Fixed chart logo link |
| 1.0.3 | 7.2.7 | Updated to Valkey 7.2.7 |
| 1.0.4 | 7.2.9 | Updated to Valkey 7.2.9 |
| 1.0.5 | 7.2.10 | Updated to Valkey 7.2.10, redis_exporter 1.77.0 |
| 1.0.6 | 7.2.11 | Updated to Valkey 7.2.11, redis_exporter 1.80.0 |
| 1.0.7 | 7.2.12 | Updated to Valkey 7.2.12 |
| 1.0.8 | 7.2.13 | Updated to Valkey 7.2.13, redis_exporter 1.84.0 |
| 2.0.0 | 8.0.1 | Updated to Valkey 8.0.1 |
| 2.0.1 | 8.0.3 | Updated to Valkey 8.0.3 |
| 2.0.2 | 8.0.5 | Updated to Valkey 8.0.5, redis_exporter 1.77.0 |
| 2.0.3 | 8.0.6 | Updated to Valkey 8.0.6, redis_exporter 1.80.0 |
| 2.0.4 | 8.0.7 | Updated to Valkey 8.0.7 |
| 2.0.5 | 8.0.9 | Updated to Valkey 8.0.9, redis_exporter 1.84.0 |
| 2.1.0 | 8.1.2 | Updated to Valkey 8.1.2 |
| 2.1.1 | 8.1.2 | Added support for loadBalancerSourceRanges |
| 2.1.2 | 8.1.2 | Added authentication for valkey-cli during init phase - thx @Loki-Afro |
| 2.1.3 | 8.1.3 | Updated to Valkey 8.1.3, redis_exporter 1.75.0 |
| 2.1.4 | 8.1.3 | Updated to Valkey 8.1.3, redis_exporter 1.77.0 |
| 2.1.5 | 8.1.4 | Updated to Valkey 8.1.4 |
| 2.1.6 | 8.1.4 | Added priorityClassName - thx @JimCronqvist |
| 2.1.7 | 8.1.5 | Updated to Valkey 8.1.5 |
| 2.1.8 | 8.1.6 | Updated to Valkey 8.1.6 |
| 2.1.9 | 8.1.7 | Updated to Valkey 8.1.7, redis_exporter 1.84.0 |
| 2.1.10 | 8.1.8 | Updated to Valkey 8.1.8 |
| 2.2.0 | 9.0.0 | Updated to Valkey 9.0.0 |
| 2.2.1 | 9.0.0 | Implemented support for Alpine container image version - thx @martins-ricardo |
| 2.2.2 | 9.0.0 | Fixed DNS name resolution problem during failover - thx @pschiffe |
| 2.2.3 | 9.0.0 | Added support for persistentVolumeClaimRetentionPolicy |
| 2.2.4 | 9.0.2 | Updated to Valkey 9.0.2 |
| 2.2.5 | 9.0.3 | Updated to Valkey 9.0.3 |
| 2.2.6 | 9.0.4 | Updated to Valkey 9.0.4, redis_exporter 1.84.0 |
| 2.3.0 | 9.1.0 | Updated to Valkey 9.1.0, redis_exporter 1.84.0 |
| 2.3.1 | 9.1.0 | Fixed PVC definition - thx @trandbert37 |
| 2.3.2 | 9.1.0 | Fixed README.md markdown formatting |
| 2.3.3 | 9.1.1 | Upgraded valkey to 9.1.1 |
| 2.3.4 | 9.1.2 | Upgraded valkey to 9.1.2 |
| 2.3.5 | 9.1.3 | Upgraded valkey to 9.1.3 |
| | | |
